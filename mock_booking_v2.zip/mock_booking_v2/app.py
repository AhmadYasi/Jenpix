"""
Mock Booking.com Backend
Run with:  pip install flask flask-cors && python app.py
Server:    http://localhost:5000
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime
import uuid
import time

app = Flask(__name__)
CORS(app)  # Allow frontend (different port) to call this backend

# ─────────────────────────────────────────────
# "DATABASE" — plain Python dicts/lists in memory
# (data resets when server restarts)
# ─────────────────────────────────────────────

HOTELS = {
    "BER001": {"id": "BER001", "name": "Hotel Adlon Kempinski", "city": "berlin", "location": "Unter den Linden, Berlin", "stars": 5, "rating": 9.1, "emoji": "🏛️", "price": 289, "amenities": ["WiFi", "Spa", "Pool", "Restaurant"], "rooms_left": 3},
    "BER002": {"id": "BER002", "name": "Moxy Berlin Ostbahnhof", "city": "berlin", "location": "Friedrichshain, Berlin", "stars": 3, "rating": 8.3, "emoji": "🎨", "price": 89, "amenities": ["WiFi", "Bar", "Gym"], "rooms_left": 12},
    "BER003": {"id": "BER003", "name": "25hours Hotel Bikini", "city": "berlin", "location": "Charlottenburg, Berlin", "stars": 4, "rating": 8.7, "emoji": "🌿", "price": 149, "amenities": ["WiFi", "Restaurant", "Rooftop"], "rooms_left": 1},
    "PAR001": {"id": "PAR001", "name": "Hôtel Le Marais", "city": "paris", "location": "Le Marais, Paris", "stars": 4, "rating": 8.9, "emoji": "🗼", "price": 198, "amenities": ["WiFi", "Restaurant", "Concierge"], "rooms_left": 5},
    "PAR002": {"id": "PAR002", "name": "ibis Paris Bastille", "city": "paris", "location": "11e arrondissement, Paris", "stars": 3, "rating": 7.8, "emoji": "🥐", "price": 95, "amenities": ["WiFi", "Bar"], "rooms_left": 20},
    "PAR003": {"id": "PAR003", "name": "Hôtel Particulier Montmartre", "city": "paris", "location": "Montmartre, Paris", "stars": 5, "rating": 9.4, "emoji": "🎭", "price": 390, "amenities": ["WiFi", "Pool", "Spa", "Garden"], "rooms_left": 2},
    "ROM001": {"id": "ROM001", "name": "Hotel de Russie", "city": "rome", "location": "Via del Babuino, Rome", "stars": 5, "rating": 9.2, "emoji": "🏛️", "price": 450, "amenities": ["WiFi", "Spa", "Garden", "Restaurant"], "rooms_left": 4},
    "ROM002": {"id": "ROM002", "name": "The Beehive", "city": "rome", "location": "Termini, Rome", "stars": 2, "rating": 8.1, "emoji": "🐝", "price": 55, "amenities": ["WiFi", "Cafe"], "rooms_left": 8},
    "GEN001": {"id": "GEN001", "name": "City Center Hotel", "city": "generic", "location": "Downtown", "stars": 3, "rating": 7.5, "emoji": "🏨", "price": 85, "amenities": ["WiFi", "Breakfast"], "rooms_left": 10},
    "GEN002": {"id": "GEN002", "name": "Grand Palace Hotel", "city": "generic", "location": "Old Town", "stars": 4, "rating": 8.2, "emoji": "🏰", "price": 135, "amenities": ["WiFi", "Pool", "Restaurant"], "rooms_left": 6},
}

# Bookings made by users  {booking_ref: booking_dict}
BOOKINGS = {}

# Request log for the admin panel  [log_entry, ...]
REQUEST_LOG = []


# ─────────────────────────────────────────────
# HELPER — log every API call
# ─────────────────────────────────────────────

def log_request(endpoint, method, params, response_status):
    REQUEST_LOG.insert(0, {           # insert at front so newest is first
        "id": str(uuid.uuid4())[:8],
        "timestamp": datetime.now().strftime("%H:%M:%S"),
        "method": method,
        "endpoint": endpoint,
        "params": params,
        "status": response_status,
    })
    if len(REQUEST_LOG) > 100:        # keep only last 100 entries
        REQUEST_LOG.pop()


# ─────────────────────────────────────────────
# ENDPOINT 1 — Search hotels
# GET /api/hotels/search?destination=berlin&checkin=...&checkout=...&adults=2&rooms=1
# ─────────────────────────────────────────────

@app.route("/api/hotels/search")
def search_hotels():
    destination = request.args.get("destination", "").lower()
    checkin     = request.args.get("checkin", "")
    checkout    = request.args.get("checkout", "")
    adults      = int(request.args.get("adults", 2))
    rooms       = int(request.args.get("rooms", 1))

    # Work out nights so we can calculate total price
    try:
        d1 = datetime.strptime(checkin, "%Y-%m-%d")
        d2 = datetime.strptime(checkout, "%Y-%m-%d")
        nights = max(1, (d2 - d1).days)
    except ValueError:
        nights = 1

    # Filter hotels by city keyword
    matched = []
    for hotel in HOTELS.values():
        if hotel["city"] in destination or destination in hotel["city"] or hotel["city"] == "generic":
            # only include generic hotels if no city matched
            if hotel["city"] == "generic":
                city_matched = any(h["city"] != "generic" and h["city"] in destination for h in HOTELS.values())
                if city_matched:
                    continue
            h = dict(hotel)                   # copy so we don't mutate the DB
            h["nights"]      = nights
            h["price_night"] = h["price"]
            h["price_total"] = h["price"] * nights * rooms
            h["currency"]    = "EUR"
            matched.append(h)

    response = {
        "search_id":     "SRCH_" + str(uuid.uuid4())[:8].upper(),
        "destination":   destination,
        "checkin":       checkin,
        "checkout":      checkout,
        "nights":        nights,
        "adults":        adults,
        "rooms":         rooms,
        "results_count": len(matched),
        "hotels":        matched,
    }

    log_request("/api/hotels/search", "GET", dict(request.args), 200)
    return jsonify(response), 200


# ─────────────────────────────────────────────
# ENDPOINT 2 — Get single hotel by ID
# GET /api/hotels/<hotel_id>
# ─────────────────────────────────────────────

@app.route("/api/hotels/<hotel_id>")
def get_hotel(hotel_id):
    hotel = HOTELS.get(hotel_id.upper())
    if not hotel:
        log_request(f"/api/hotels/{hotel_id}", "GET", {}, 404)
        return jsonify({"error": "Hotel not found", "hotel_id": hotel_id}), 404

    log_request(f"/api/hotels/{hotel_id}", "GET", {}, 200)
    return jsonify(hotel), 200


# ─────────────────────────────────────────────
# ENDPOINT 3 — Check room availability
# GET /api/hotels/<hotel_id>/availability
# ─────────────────────────────────────────────

@app.route("/api/hotels/<hotel_id>/availability")
def check_availability(hotel_id):
    hotel = HOTELS.get(hotel_id.upper())
    if not hotel:
        return jsonify({"error": "Hotel not found"}), 404

    result = {
        "hotel_id":    hotel_id,
        "hotel_name":  hotel["name"],
        "available":   hotel["rooms_left"] > 0,
        "rooms_left":  hotel["rooms_left"],
        "price_night": hotel["price"],
        "currency":    "EUR",
    }

    log_request(f"/api/hotels/{hotel_id}/availability", "GET", dict(request.args), 200)
    return jsonify(result), 200


# ─────────────────────────────────────────────
# ENDPOINT 4 — Create a booking
# POST /api/reservations
# Body (JSON): { hotel_id, checkin, checkout, adults, rooms, guest_name, email }
# ─────────────────────────────────────────────

@app.route("/api/reservations", methods=["POST"])
def create_reservation():
    body = request.get_json()
    if not body:
        return jsonify({"error": "Request body must be JSON"}), 400

    hotel_id = body.get("hotel_id", "").upper()
    hotel    = HOTELS.get(hotel_id)
    if not hotel:
        log_request("/api/reservations", "POST", body, 404)
        return jsonify({"error": "Hotel not found"}), 404

    if hotel["rooms_left"] < 1:
        log_request("/api/reservations", "POST", body, 409)
        return jsonify({"error": "No rooms available"}), 409

    # Calculate total
    checkin  = body.get("checkin", "")
    checkout = body.get("checkout", "")
    rooms    = int(body.get("rooms", 1))
    try:
        d1 = datetime.strptime(checkin, "%Y-%m-%d")
        d2 = datetime.strptime(checkout, "%Y-%m-%d")
        nights = max(1, (d2 - d1).days)
    except ValueError:
        nights = 1

    total = hotel["price"] * nights * rooms

    # Build booking record
    ref = "BK" + str(uuid.uuid4())[:8].upper()
    booking = {
        "booking_reference":     ref,
        "status":                "confirmed",
        "hotel_id":              hotel_id,
        "hotel_name":            hotel["name"],
        "hotel_location":        hotel["location"],
        "checkin":               checkin,
        "checkout":              checkout,
        "nights":                nights,
        "rooms":                 rooms,
        "adults":                body.get("adults", 2),
        "guest_name":            body.get("guest_name", "Guest"),
        "email":                 body.get("email", ""),
        "price_per_night":       hotel["price"],
        "total_price":           total,
        "currency":              "EUR",
        "cancellation_policy":   "Free cancellation until 24h before check-in",
        "created_at":            datetime.now().isoformat(),
    }

    BOOKINGS[ref] = booking

    # Reduce available rooms
    HOTELS[hotel_id]["rooms_left"] -= rooms

    log_request("/api/reservations", "POST", body, 201)
    return jsonify(booking), 201


# ─────────────────────────────────────────────
# ENDPOINT 5 — Get a booking by reference
# GET /api/reservations/<booking_ref>
# ─────────────────────────────────────────────

@app.route("/api/reservations/<booking_ref>")
def get_reservation(booking_ref):
    booking = BOOKINGS.get(booking_ref.upper())
    if not booking:
        log_request(f"/api/reservations/{booking_ref}", "GET", {}, 404)
        return jsonify({"error": "Booking not found"}), 404

    log_request(f"/api/reservations/{booking_ref}", "GET", {}, 200)
    return jsonify(booking), 200


# ─────────────────────────────────────────────
# ENDPOINT 6 — Cancel a booking
# DELETE /api/reservations/<booking_ref>
# ─────────────────────────────────────────────

@app.route("/api/reservations/<booking_ref>", methods=["DELETE"])
def cancel_reservation(booking_ref):
    booking = BOOKINGS.get(booking_ref.upper())
    if not booking:
        log_request(f"/api/reservations/{booking_ref}", "DELETE", {}, 404)
        return jsonify({"error": "Booking not found"}), 404

    if booking["status"] == "cancelled":
        return jsonify({"error": "Already cancelled"}), 409

    booking["status"] = "cancelled"
    booking["cancelled_at"] = datetime.now().isoformat()

    # Give the room back
    hotel_id = booking["hotel_id"]
    if hotel_id in HOTELS:
        HOTELS[hotel_id]["rooms_left"] += booking["rooms"]

    log_request(f"/api/reservations/{booking_ref}", "DELETE", {}, 200)
    return jsonify({"message": "Booking cancelled", "booking_reference": booking_ref}), 200


# ─────────────────────────────────────────────
# ADMIN ENDPOINTS — only used by admin panel
# ─────────────────────────────────────────────

@app.route("/api/admin/logs")
def get_logs():
    return jsonify({"logs": REQUEST_LOG}), 200


@app.route("/api/admin/bookings")
def get_all_bookings():
    return jsonify({"bookings": list(BOOKINGS.values())}), 200


@app.route("/api/admin/hotels")
def get_all_hotels():
    return jsonify({"hotels": list(HOTELS.values())}), 200


@app.route("/api/admin/stats")
def get_stats():
    total      = len(BOOKINGS)
    confirmed  = sum(1 for b in BOOKINGS.values() if b["status"] == "confirmed")
    cancelled  = sum(1 for b in BOOKINGS.values() if b["status"] == "cancelled")
    revenue    = sum(b["total_price"] for b in BOOKINGS.values() if b["status"] == "confirmed")
    return jsonify({
        "total_bookings":     total,
        "confirmed_bookings": confirmed,
        "cancelled_bookings": cancelled,
        "total_revenue_eur":  revenue,
        "total_requests":     len(REQUEST_LOG),
        "hotels_count":       len(HOTELS),
    }), 200


# ─────────────────────────────────────────────

if __name__ == "__main__":
    print("\n🚀 Mock Booking API running at http://localhost:5000")
    print("📋 Admin endpoints: /api/admin/logs  /api/admin/bookings  /api/admin/stats\n")
    app.run(debug=True, port=5000)
